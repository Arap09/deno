from fastapi import APIRouter
router = APIRouter(prefix='/auth')

@router.get('/')
def get_auth_status():
    return {'message': 'Auth route working'}
