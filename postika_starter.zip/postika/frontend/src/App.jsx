import React from 'react';
import Hello from './components/Hello';
function App() { return (<div className='p-10'><h1>POSTIKA Frontend</h1><Hello /></div>); }
export default App;