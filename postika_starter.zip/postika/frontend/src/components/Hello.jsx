import React from 'react';
export default function Hello() { return <p>Hello from POSTIKA!</p>; }