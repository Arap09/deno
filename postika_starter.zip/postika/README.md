# POSTIKA SaaS Starter

- Backend: FastAPI on port 8000
- Frontend: React + Vite on port 5173 (or Codespaces forwarded port)
- Run backend:
  ```bash
  cd backend
  pip install -r requirements.txt
  uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
  ```
- Run frontend:
  ```bash
  cd frontend
  npm install
  npm run dev
  ```